
fetch('data/products.json')
.then(r=>r.json())
.then(data=>{
  const el=document.getElementById('products')
  data.forEach(p=>{
    el.innerHTML+=`
    <div class="card">
      <img src="${p.img}">
      <h3>${p.name}</h3>
      <p>${p.price} zł</p>
      <a href="product.html?id=${p.id}">Zobacz</a>
    </div>`
  })
})
