
const id=new URLSearchParams(location.search).get('id')
fetch('data/products.json')
.then(r=>r.json())
.then(data=>{
  const p=data.find(x=>x.id==id)
  document.getElementById('product').innerHTML=`
  <h1>${p.name}</h1>
  <img src="${p.img}">
  <p>${p.desc}</p>
  <h2>${p.price} zł</h2>`
})
